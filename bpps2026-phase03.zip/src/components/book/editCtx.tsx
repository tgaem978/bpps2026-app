import { createContext, useContext, useMemo, useState, type ReactNode } from 'react';
import type { Block } from '@/types/book';
import { useBookStore } from '@/stores/bookStore';

/** Pemilihan dalam pratonton: kunci segmen blok ("idBlok-from"), dan sel jadual (r = -1 kepala, -2 = bukan sel). */
export interface EditSel { key: string; r: number; c: number }
interface Root { sel: EditSel | null; select: (s: EditSel | null) => void }
const RootCtx = createContext<Root | null>(null);
const SectionCtx = createContext<string | null>(null);

/** Akar pratonton boleh sunting: memegang pemilihan; klik ruang kosong membatalkan pemilihan. */
export function EditRoot({ children }: { children: ReactNode }) {
  const [sel, select] = useState<EditSel | null>(null);
  const value = useMemo(() => ({ sel, select }), [sel]);
  return (
    <RootCtx.Provider value={value}>
      <div onClick={() => select(null)}>{children}</div>
    </RootCtx.Provider>
  );
}

/** Menetapkan tajuk (section) bagi blok-blok pada halaman yang dipaparkan. */
export function EditSection({ sectionId, children }: { sectionId: string; children: ReactNode }) {
  return <SectionCtx.Provider value={sectionId}>{children}</SectionCtx.Provider>;
}

export interface EditApi extends Root { update: (block: Block) => void }
/** null di luar pratonton sunting (cetakan, pengukur halaman, buku penuh) → tiada bar atau pemegang. */
export function useEdit(): EditApi | null {
  const root = useContext(RootCtx);
  const sectionId = useContext(SectionCtx);
  if (!root || !sectionId) return null;
  return { ...root, update: (block) => useBookStore.getState().updateBlock(sectionId, block.id, block) };
}
