import type { MouseEvent as RMouse, ReactNode } from 'react';
import { AlignCenter, AlignJustify, AlignLeft, AlignRight, Bold, IndentDecrease, IndentIncrease, Italic, Underline } from 'lucide-react';
import type { TextFormat } from '@/types/book';
import { clampIndent } from '@/lib/format';

/**
 * Bar format teks (rata kiri/tengah/kanan/kiri-kanan, tebal, senget, garis bawah, inden).
 * Digunakan dalam pratonton halaman; boleh juga dipasang dalam panel editor blok.
 * `defaultBold`: kepala jadual asalnya tebal. `onChange` menerima perubahan sahaja (undefined = buang tetapan).
 */
export function FormatBar({ fmt, onChange, defaultBold = false, children }: { fmt: TextFormat; onChange: (patch: TextFormat) => void; defaultBold?: boolean; children?: ReactNode }) {
  const keep = (e: RMouse) => { e.preventDefault(); e.stopPropagation(); };
  const aligns: [NonNullable<TextFormat['align']>, ReactNode, string][] = [
    ['left', <AlignLeft size={14} />, 'Rata kiri'],
    ['center', <AlignCenter size={14} />, 'Tengah'],
    ['right', <AlignRight size={14} />, 'Rata kanan'],
    ['justify', <AlignJustify size={14} />, 'Rata kiri-kanan'],
  ];
  const bold = fmt.bold ?? defaultBold;
  const indent = fmt.indent ?? 0;
  return (
    <div className="bp-fbar" onMouseDown={keep} onClick={(e) => e.stopPropagation()} role="toolbar" aria-label="Format teks">
      {aligns.map(([v, icon, label]) => (
        <button key={v} type="button" title={label} aria-label={label} aria-pressed={fmt.align === v} onClick={() => onChange({ align: fmt.align === v ? undefined : v })}>{icon}</button>
      ))}
      <span className="sep" />
      <button type="button" title="Tebal" aria-label="Tebal" aria-pressed={bold} onClick={() => onChange({ bold: !bold })}><Bold size={14} /></button>
      <button type="button" title="Senget" aria-label="Senget" aria-pressed={!!fmt.italic} onClick={() => onChange({ italic: fmt.italic ? undefined : true })}><Italic size={14} /></button>
      <button type="button" title="Garis bawah" aria-label="Garis bawah" aria-pressed={!!fmt.underline} onClick={() => onChange({ underline: fmt.underline ? undefined : true })}><Underline size={14} /></button>
      <span className="sep" />
      <button type="button" title="Kurangkan inden" aria-label="Kurangkan inden" disabled={!indent} onClick={() => onChange({ indent: clampIndent(indent - 1) })}><IndentDecrease size={14} /></button>
      <button type="button" title="Tambah inden" aria-label="Tambah inden" onClick={() => onChange({ indent: clampIndent(indent + 1) })}><IndentIncrease size={14} /></button>
      {children}
    </div>
  );
}
