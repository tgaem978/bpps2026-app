import type { CSSProperties } from 'react';
import type { TableBlock, TextFormat } from '@/types/book';

export const INDENT_MM = 6;
export const MAX_INDENT = 8;

/** Format → gaya CSS. mode 'margin' (perenggan/senarai) atau 'padding' (sel jadual; asas = ruang sel lalai). */
export function fmtStyle(f?: TextFormat, mode: 'margin' | 'padding' = 'margin', basePad = 1.4): CSSProperties {
  if (!f) return {};
  const st: CSSProperties = {};
  if (f.align) st.textAlign = f.align;
  if (f.bold !== undefined) st.fontWeight = f.bold ? 700 : 400;
  if (f.italic !== undefined) st.fontStyle = f.italic ? 'italic' : 'normal';
  if (f.underline !== undefined) st.textDecoration = f.underline ? 'underline' : 'none';
  if (f.indent) {
    if (mode === 'margin') st.marginLeft = `calc(var(--mm) * ${f.indent * INDENT_MM})`;
    else st.paddingLeft = `calc(var(--mm) * ${basePad + f.indent * 4})`;
  }
  return st;
}

export const cellKey = (r: number, c: number) => `${r},${c}`;
/** Format berkesan sel: format jadual ditimpa format sel. */
export const cellFormat = (b: TableBlock, r: number, c: number): TextFormat => ({ ...(b.fmt ?? {}), ...(b.cellFmt?.[cellKey(r, c)] ?? {}) });

/** Gabung perubahan format; nilai undefined membuang tetapan. */
export function patchFormat(base: TextFormat | undefined, patch: TextFormat): TextFormat | undefined {
  const next: TextFormat = { ...(base ?? {}), ...patch };
  (Object.keys(next) as (keyof TextFormat)[]).forEach((k) => { if (next[k] === undefined || next[k] === 0) delete next[k]; });
  return Object.keys(next).length ? next : undefined;
}

export const clampIndent = (n: number) => Math.max(0, Math.min(MAX_INDENT, n));
